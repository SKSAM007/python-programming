num = 153
order = len(str(num))
sum = 0
temp = num
while temp > 0:
   digit = temp % 10
   sum += digit ** order
   temp //= 10
if num == sum:
   print("Given number is an Armstrong number")
else:
   print("Given number is not an Armstrong number")
